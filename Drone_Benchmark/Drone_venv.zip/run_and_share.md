# Run locally and share with a system-ROS .venv

## For single drone commands
In Terminal 1:

```bash
cd ~/drone_obstacle_course
source ~/miniconda3/etc/profile.d/conda.sh
conda activate drone-ros-jazzy
python scripts/start_simulation.py --ros conda --n 1
```
The launcher starts agent, Gazebo, PX4, MAVProxy

In Terminal 2:

```bash
cd ~/drone_obstacle_course
source ~/miniconda3/etc/profile.d/conda.sh
conda activate drone-ros-jazzy
source install-conda/local_setup.bash
ros2 run swarm_mavsdk_ros2 control_console --drone 0
```

Enter these commands one at a time, waiting for each to finish:

These are the primitives, startup and arm are needed for any other movement

```text
startup
arm
takeoff
forward 0.5
backward 0.5
right 0.5
left 0.5
up 0.5
down 0.5
land
```
To run X (with X being an integer of drones in a swarm) drones, stop the previous simulation and change Terminal 1 to:

```bash
python scripts/start_simulation.py --ros conda --n X
```

In Terminal 2, activate Conda and source `install-conda/local_setup.bash` again.
Run each line separately:

```bash
ros2 run swarm_mavsdk_ros2 swarm_command startup --n X
ros2 run swarm_mavsdk_ros2 swarm_command arm --n X
ros2 run swarm_mavsdk_ros2 swarm_command takeoff --n X
ros2 run swarm_mavsdk_ros2 swarm_command forward 0.5 --n X
ros2 run swarm_mavsdk_ros2 swarm_command land --n X
```

After all drones touch down:

```bash
ros2 run swarm_mavsdk_ros2 swarm_command disarm --n X
```

To control single drones from the swarm, `control_console --drone 1` or `--drone 2` to control an individual member. Every member has its own PX4 commander and ROS interface; they share one DDS agent.

## Coordinated takeoff

Use `swarm_command takeoff --n X` to dispatch the entire fleet together.
The controller discovers every takeoff service before sending any request,
then queues all requests without waiting between members. Each drone retains
its continuously warmed OFFBOARD stream instead of restarting its warmup.
Takeoff still waits until every drone reaches and settles at its configured
height before allowing the next command. Independent ROS timers and PX4
controllers can produce small differences in physical liftoff; this is not
an exact shared simulation-tick trigger.

Restart the launcher after a source change and allow its normal build (omit
`--skip-build`) so the installed nodes include the change.


## Native prerequisites

Target Ubuntu 24.04 Linux with its `/usr/bin/python3` (Python 3.12).
Use a clean terminal with Conda deactivated. Follow the official
[ROS Jazzy binary installation](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)
and [Gazebo Harmonic installation](https://gazebosim.org/docs/harmonic/install_ubuntu/)
to configure their apt repositories. Then install:

```bash
sudo apt update
sudo apt install ros-jazzy-ros-base ros-jazzy-geometry-msgs \
  ros-jazzy-nav-msgs ros-jazzy-std-msgs ros-jazzy-std-srvs \
  ros-jazzy-rcl-interfaces ros-jazzy-rosidl-default-generators \
  ros-jazzy-rosidl-default-runtime python3-colcon-common-extensions \
  python3-venv python3-pip python3-numpy build-essential cmake git gz-harmonic
```

Retrieve PX4 at the recorded revision in a new checkout:

```bash
cd ~
git clone https://github.com/PX4/PX4-Autopilot.git
cd PX4-Autopilot
git checkout d6f12ad1c4f70ad3230afd7d86e971421e02fef4
git submodule update --init --recursive
bash Tools/setup/ubuntu.sh
```

Follow any reboot instructions from the installer, then build:

```bash
cd ~/PX4-Autopilot
make px4_sitl_default
```

PX4's [Ubuntu setup guide](https://docs.px4.io/main/en/dev_setup/dev_env_linux_ubuntu)
describes the native toolchain setup. Check `gz sim --versions`: this project
uses Harmonic (gz-sim 8).

Build the agent from the v2.4.3 source recommended in PX4's
[ROS guide](https://docs.px4.io/main/en/ros2/user_guide), using a **new directory**:

```bash
cd ~
git clone --branch v2.4.3 https://github.com/eProsima/Micro-XRCE-DDS-Agent.git
cd Micro-XRCE-DDS-Agent
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
sudo cmake --install build
sudo ldconfig
command -v MicroXRCEAgent
```

## Recipient: unpack and create .venv

Place the archive in your home directory and run:

```bash
cd ~
tar -xzf drone_obstacle_course-source.tar.gz
cd drone_obstacle_course
/usr/bin/python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -r requirements-venv.txt
python -m pip check
```

